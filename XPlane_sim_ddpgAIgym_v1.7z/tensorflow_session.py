import tensorflow as tf

class tfs:
    session = tf.Session()
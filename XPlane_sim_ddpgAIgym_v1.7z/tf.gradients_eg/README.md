## Using tf.gradients for optimizing loss function

This code contains the optimization of linear regression parameters using tf.gradients. This will be useful in understanding the optimization of actor network in the DDPG algorithm

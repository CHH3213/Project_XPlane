# jjjLib1 Manual

This is the manual of the jjjLib1 library. But as you can see, it isn't ready yet.

You want to help us? You can write a manual for this library and I will publish it here.

Thanks!
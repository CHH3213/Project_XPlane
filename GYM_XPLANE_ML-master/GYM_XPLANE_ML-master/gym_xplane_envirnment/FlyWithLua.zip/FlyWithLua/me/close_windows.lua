
-- function to close open windows 


local clock = os.clock
function sleep(n)  -- seconds
  local t0 = clock()
  while clock() - t0 <= n do end
end




function closer()
    	sleep(10)
	command_once( "sim/operation/close_windows" )
 
end


--while true do 
	--[[sleep(0.90)
	logMsg("Closing Windows")
	create_command( "FlyWithLua/train/close", "Close Windows",
                "closer()",
                "",
                "")]]
--end

function closed()
	do_every_frame("close Windows","close()")
end 

--add_macro("add_macro", "closed()")
add_macro( "add micro", "closed()","","activate" )


